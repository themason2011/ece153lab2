/*
 * ECE 153B - Winter 2020
 *
 * Name(s): Mason Corey, Andrea Anez
 * Section: Thursday 7PM
 * Lab: 2B
 */
 
#include "stm32l476xx.h"

#include "LCD.h"
#include "LED.h"
#include "RTC.h"
#include "SysClock.h"

char strTime[12] = {0};
char strDate[12] = {0};

void RTC_Set_Alarm(void) {
	
	RTC->CR &= ~RTC_CR_ALRAE; //Disable both alarms before setting up
	RTC->CR &= ~RTC_CR_ALRBE;
	
	RTC_Disable_Write_Protection(); //Disable write protection
	
	//Clear the alarm enable bit and interrupt enable bit for A and B
	RTC->CR &= ~RTC_CR_ALRAE; //Disable both alarms before setting up
	RTC->CR &= ~RTC_CR_ALRBE;
	RTC->CR &= ~RTC_CR_ALRAIE; //Disable both interrupts before setting up
	RTC->CR &= ~RTC_CR_ALRBIE;
	
	while(1) {                      //Wait for both ALRAWF and ALRBWF to be set to 1, once they are continue
		if(((RTC->ISR & RTC_ISR_ALRAWF) != 0) && ((RTC->ISR & RTC_ISR_ALRBWF) != 0)) {
				break;
			}
	}
	

	
	//Set RTC_ALRMAR to trigger at 30 seconds
	RTC->ALRMAR &= ~RTC_ALRMAR_SU; //Set Seconds units to 0
	RTC->ALRMAR |= RTC_ALRMAR_ST; //Set Seconds tens to 3
	RTC->ALRMAR &= ~RTC_ALRMAR_ST_2; //Set Seconds tens to 3
	RTC->ALRMAR |= RTC_ALRMAR_MSK4; //Days don't care in alarm comparison
	RTC->ALRMAR |= RTC_ALRMAR_MSK3; //Hours don't care in alarm comparison
	RTC->ALRMAR |= RTC_ALRMAR_MSK2; //Minutes don't care in alarm comparison
	RTC->ALRMAR &= ~RTC_ALRMAR_MSK1; //Alarm A set if seconds match
	
	//Set RTC_ALRMBR to trigger every second
	RTC->ALRMBR |= RTC_ALRMBR_MSK4; //Days don't care in alarm comparison
	RTC->ALRMBR |= RTC_ALRMBR_MSK3; //Hours don't care in alarm comparison
	RTC->ALRMBR |= RTC_ALRMBR_MSK2; //Minutes don't care in alarm comparison
	RTC->ALRMBR |= RTC_ALRMBR_MSK1; //Seconds don't care in alarm comparison
	
	//Set the alarm enable bit and interrupt enable bit for A and B
	RTC->CR |= RTC_CR_ALRAE; //Enable both alarms
	RTC->CR |= RTC_CR_ALRBE;
	RTC->CR |= RTC_CR_ALRAIE; //Enable both interrupts
	RTC->CR |= RTC_CR_ALRBIE;
	
	RTC_Enable_Write_Protection(); //Enable write protection
}

void RTC_Alarm_Enable(void) {
	EXTI->RTSR1 |= EXTI_RTSR1_RT18; //Enables interrupt trigger on rising edge
	
	EXTI->IMR1 |= EXTI_IMR1_IM18; //Set the interrupt mask and event mask
	EXTI->EMR1 |= EXTI_EMR1_EM18;
	
	EXTI->PR1 |= EXTI_PR1_PIF18; //Clear pending interrupt
	
	NVIC_EnableIRQ(RTC_Alarm_IRQn); //Enable interrupt in NVIC and set priority
	NVIC_SetPriority(RTC_Alarm_IRQn, 0);
}

void RTC_Alarm_IRQHandler(void) {
	EXTI->PR1 |= EXTI_PR1_PIF18; //Clear pending interrupt

	if((RTC->ISR & RTC_ISR_ALRAF) != 0) { //Alarm was A, toggle Red LED
		Red_LED_Toggle();
	}
	if((RTC->ISR & RTC_ISR_ALRBF) != 0) { //Alarm was B, toggle Red LED
		Green_LED_Toggle();
	}
}

int main(void) {	
	System_Clock_Init(); // Switch System Clock = 80 MHz
	
	LED_Init();
	LCD_Initialization();
	
	RTC_Init();
	RTC_Alarm_Enable();
	RTC_Set_Alarm();
	char str[6];
	while(1) {
		Get_RTC_Calendar(strTime, strDate);
		LCD_DisplayString((uint8_t*)strTime);
		//int time = 26251;
		//sprintf(str,"%6d",time);
		//LCD_DisplayString((uint8_t*)str);
	}
}
